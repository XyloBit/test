<?php

use App\Http\Controllers\ApiController;
use App\Http\Middleware\Api\ApiMiddleware;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;


Route::get('/', function () {
    return view('403');
});

/**************** Routing For Android/Ios Application *****************/
$callback = function () {
    Route::post('/login', 'login');
    Route::any('/getUsers', 'getUsers');
};

/**************** Normal Routing Start *****************/
Route::controller(ApiController::class)->group($callback);
//Route::middleware([ApiMiddleware::class])->prefix('v1')->controller(ApiController::class)->group($callback);
/**************** Normal Routing End *******************/



/**************** Routing For Clear Cache Start *****************/
Route::any('/clear', function () {
    Artisan::call('route:cache');
    Artisan::call('config:cache');
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
    Artisan::call('optimize:clear');
    return 'Cache Cleared';
});
/**************** Routing For Clear Cache End *****************/
