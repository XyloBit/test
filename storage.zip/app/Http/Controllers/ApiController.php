<?php

namespace App\Http\Controllers;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;


class ApiController extends BaseController
{

    public function getUsers()
    {



        $users = DB::table('users')->get();

//        return (['success' => true, 'data' => $users]);
        return (['success' => true]);
    }


//    public function deleteMessage()
//    {
//        $id = $this->params['uid'];
//
//        DB::beginTransaction();
//
//        try {
//            $message = Message::find($id);
//
//            if (!$message) {
//                return response()->json(['success' => false, 'message' => 'Message not found'], 404);
//            }
//
//            $data = [
//                'added_by' => $message->added_by,
//                'sms_number' => $message->sms_number,
//                'service_type' => $message->service_type,
//                'service_number' => $message->service_number,
//                'message' => $message->message,
//                'image' => $message->image,
//                'media_type' => $message->media_type,
//                'read_status' => $message->read_status,
//                'sent_status' => $message->sent_status,
//                'error' => $message->error,
//                'error_code' => $message->error_code,
//                'data' => $message->data,
//                'epoch_time' => $message->epoch_time,
//                'campaign_name' => $message->campaign_name,
//            ];
//
//            DB::table('delete_messages')->insert($data);
//
//            $message->delete();
//
//            DB::commit();
//
//            return response()->json(['success' => true, 'message' => 'Message deleted successfully']);
//
//        } catch (\Exception $e) {
//            DB::rollback();
//            return response()->json(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()], 500);
//        }
//    }


}
